# Overlord

A bot meant for ndemic server purposes.

You can join the server here: https://discord.com/invite/ndemic

This bot is in service from **5.25.2021 to now**

Features:
- AutoNicknamer: Make people more pingable by adding a prefix into their names.
- AutoMute: Auto message jail people if they are spamming similar messages within a time period.

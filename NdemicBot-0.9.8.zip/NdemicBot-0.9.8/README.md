# Overlord

A bot meant for ndemic server purposes.

You can join the server here: https://discord.com/invite/ndemic

This bot is in service from **5.25.2021 to now**

## Plugins Supported:
0.9.8 - now: **DiSky v2.1**<br>
0.7 - 0.9.6X: **DiSky v1.12**<br>
0.5 beta - 0.6.4: **Vixio 2.0.7**

## Features:
- AutoNicknamer: Make people more pingable by adding a prefix into their names.
- AutoMute: Auto message jail people if they are spamming similar messages within a time period.
- DM Assist: ModMail but without the channel hassles.
- Authority: How much influence you have over your peers.
